// Export the new SuperAdminDashboard component from the structured folder
export { default } from './SuperAdminDashboard';
